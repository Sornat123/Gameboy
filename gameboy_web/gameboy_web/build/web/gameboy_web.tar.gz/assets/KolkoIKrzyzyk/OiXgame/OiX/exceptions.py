class InvalidMoveError(Exception):
    pass